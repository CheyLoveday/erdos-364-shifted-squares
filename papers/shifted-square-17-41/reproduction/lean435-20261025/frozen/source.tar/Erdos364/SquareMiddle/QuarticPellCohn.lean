import Erdos364.SquareMiddle.QuarticPellCounterexample
import Erdos364.SquareMiddle.PellDivisibilityRank

namespace Erdos364

/-!
# Conditional Cohn bridge for divisible quartic Pell data

This file records the exact external theorem interface needed to remove the
Pell index from a square-middle counterexample.  It does **not** add Cohn's
classification as an axiom: `CohnQuarticPellClassification` is a proposition
which every downstream theorem takes as an explicit argument.

Literature source lock for that proposition:

* J. H. E. Cohn, *The Diophantine equation x⁴ - Dy² = 1, II*,
  Acta Arith. 78 (1997), no. 4, 401–403,
  DOI `10.4064/aa-78-4-401-403`.
* Gary Walsh, *The Diophantine equation X² - db²Y⁴ = 1*,
  Acta Arith. 87 (1998), no. 2, 179–188,
  DOI `10.4064/aa-87-2-179-188`, Theorem A (restatement).

The second Cohn branch is written as `X² + 1 = 2 A²`.  This is equivalent
to `X² = 2 A² - 1` over the intended positive naturals but avoids truncated
natural subtraction.
-/

/-- Explicit external-theorem interface for Cohn's quartic-Pell
classification on the exact source-preserving data used here.  The selected
`fundamentalX` is Mathlib's positive fundamental norm-one Pell coordinate.

This is a definition of a proposition, not a project axiom or theorem. -/
def CohnQuarticPellClassification : Prop :=
  ∀ {M X Y : Nat} (h : DivisibleNatQuarticPell M X Y),
    let hM : PellKernel M := ⟨h.M_one_lt, h.M_squarefree⟩
    X ^ 2 = fundamentalX M hM ∨
      X ^ 2 + 1 = 2 * fundamentalX M hM ^ 2

private theorem two_dvd_ordinate_of_even_squarefree
    {D A B : Nat} (hsq : Squarefree D)
    (heq : A^2 = 1 + D*B^2) (h2D : 2 ∣ D) : 2 ∣ B := by
  have h4D : ¬ 4 ∣ D := by
    simpa using (Nat.squarefree_iff_prime_squarefree.mp hsq 2 Nat.prime_two)
  have hDmod : D%4=2 := by
    have h2 := Nat.mod_eq_zero_of_dvd h2D
    have h4 : D%4≠0 := by simpa only [Nat.dvd_iff_mod_eq_zero] using h4D
    omega
  have hmod := congrArg (fun k : Nat => k%4) heq
  simp only [Nat.add_mod, Nat.mul_mod, Nat.pow_mod, Nat.mod_mod, hDmod] at hmod
  have ha := Nat.mod_lt A (by decide : 0<4)
  have hb := Nat.mod_lt B (by decide : 0<4)
  interval_cases hAr : A%4 <;> interval_cases hBr : B%4 <;>
    norm_num [hAr,hBr] at hmod <;>
    apply Nat.dvd_of_mod_eq_zero <;> omega

/-- Squaring a norm-one point cannot repair squarefree-kernel saturation.
No fundamentalness or parity of the real coordinate is assumed. -/
theorem squarefree_kernel_dvd_squared_unit_ordinate_iff
    {D A B : Nat} (hsq : Squarefree D)
    (heq : A^2 = 1+D*B^2) : D ∣ 2*A*B ↔ D ∣ B := by
  constructor
  · intro hd
    by_cases hB : B=0
    · simp [hB]
    have hDA2 : D.Coprime (A^2) := by
      rw [heq]
      simpa [mul_comm] using
        (Nat.coprime_add_mul_right_right D 1 (B^2)).mpr (Nat.coprime_one_right D)
    have hDA : D.Coprime A := hDA2.of_dvd_right (dvd_pow_self A (by decide : 2≠0))
    let r := D / D.gcd B
    have hrB : r.Coprime B := Nat.coprime_div_gcd_of_squarefree hsq hB
    have hrD : r ∣ D := Nat.div_dvd_of_dvd (Nat.gcd_dvd_left D B)
    have hrA : r.Coprime A := hDA.of_dvd_left hrD
    have hr2A : r ∣ 2*A := hrB.dvd_of_dvd_mul_right (hrD.trans hd)
    have hr2 : r ∣ 2 := hrA.dvd_of_dvd_mul_right hr2A
    rcases (Nat.dvd_prime Nat.prime_two).mp hr2 with hr1 | hr2
    · have hDg : D = D.gcd B := by
        have h := Nat.div_mul_cancel (Nat.gcd_dvd_left D B)
        change r * D.gcd B = D at h
        simpa [hr1] using h.symm
      rw [hDg]
      exact Nat.gcd_dvd_right D B
    · have h2D : 2 ∣ D := by simpa [hr2] using hrD
      have h2B := two_dvd_ordinate_of_even_squarefree hsq heq h2D
      have hc : Nat.Coprime 2 B := by simpa [hr2] using hrB
      exact False.elim ((Nat.not_coprime_of_dvd_of_dvd (by decide : 1<2)
        (dvd_refl 2) h2B) hc)
  · intro hb
    exact hb.trans (dvd_mul_left B (2*A))

/-- Parity-general positive quartic-Pell classification of J. H. E. Cohn,
*The Diophantine equation x⁴ - Dy² = 1, II*, Acta Arith. 78 (1997),
401–403, DOI `10.4064/aa-78-4-401-403`, as restated in M. A. Bennett
and G. Walsh, *The Diophantine equation b²X⁴ - dY² = 1*, Proc. Amer.
Math. Soc. 127 (1999), Theorem 1.1, p. 3481,
DOI `10.1090/S0002-9939-99-05041-8`.

This is an explicit external proposition, not an axiom. The two possible
real coordinates are the first and second powers of the positive
integer-coordinate fundamental norm-one unit. Squarefreeness and D > 1
are retained through `PellKernel`; no even-root restriction is imposed. -/
def PositiveCohnQuarticPellClassification : Prop :=
  ∀ (D : Nat) (hD : PellKernel D) (X Y : Nat),
    1<X → 0<Y → X^4=1+D*Y^2 →
    X^2=fundamentalX D hD ∨ X^2+1=2*fundamentalX D hD^2

/-- The parity-general published input supplies the unchanged even-root interface. -/
theorem PositiveCohnQuarticPellClassification.toCohnQuarticPellClassification (h : PositiveCohnQuarticPellClassification) :
    CohnQuarticPellClassification := by
  intro M X Y d
  exact h M ⟨d.M_one_lt,d.M_squarefree⟩ X Y d.X_one_lt d.Y_pos
    (by simpa [Nat.add_comm] using d.equation)

/-- A positive saturated quartic source has rank one in its own outer field.
Both Cohn alternatives are retained; this does not identify a lower-field index. -/
theorem pellRank_eq_one_of_positive_cohn
    (hC : PositiveCohnQuarticPellClassification)
    {D X Y : Nat} (hD : PellKernel D) (hX : 1<X) (hY : 0<Y)
    (heq : X^4=1+D*Y^2) (hdiv : D ∣ Y) :
    pellRank D hD = 1 := by
  apply (kernel_dvd_fundamentalY_iff_pellRank_eq_one D hD).mp
  let A := fundamentalX D hD
  let B := fundamentalY D hD
  have hfund : A^2=1+D*B^2 := by
    have hf := fundamental_pell_equation D hD
    change A^2-D*B^2=1 at hf
    omega
  rcases hC D hD X Y hX hY heq with hfirst | hsecond
  · change X^2=A at hfirst
    have hsq : Y^2=B^2 := by
      apply Nat.eq_of_mul_eq_mul_left (Nat.zero_lt_of_lt hD.1)
      have hx4 : X^4=A^2 := by rw [← hfirst]; ring
      nlinarith
    have hyB : Y=B := Nat.pow_left_injective (by decide : (2:Nat)≠0) hsq
    simpa [hyB] using hdiv
  · change X^2+1=2*A^2 at hsecond
    have hs := congrArg (fun n : Nat => n^2) hsecond
    have ha := congrArg (fun n : Nat => 4*A^2*n) hfund
    have hsq : Y^2=(2*A*B)^2 := by
      apply Nat.eq_of_mul_eq_mul_left (Nat.zero_lt_of_lt hD.1)
      nlinarith [hs,ha]
    have hyB : Y=2*A*B := Nat.pow_left_injective (by decide : (2:Nat)≠0) hsq
    apply (squarefree_kernel_dvd_squared_unit_ordinate_iff hD.2 hfund).mp
    simpa [hyB] using hdiv

/-- A squarefree Pell saturation rank is always odd, including even kernels. -/
theorem pellRank_odd (D : Nat) (hD : PellKernel D) : Odd (pellRank D hD) := by
  apply Nat.coprime_two_left.mp
  apply Nat.prime_two.coprime_iff_not_dvd.mpr
  intro hr
  obtain ⟨h2D,hnot⟩ := (prime_dvd_pellRank_iff D hD 2 Nat.prime_two).mp hr
  apply hnot
  apply two_dvd_ordinate_of_even_squarefree (A:=fundamentalX D hD) hD.2 _ h2D
  have hf := fundamental_pell_equation D hD
  omega

/-- Doubling a source index cannot repair missing kernel saturation.
This is D-divisibility only, not an equivalence of full and defective depth. -/
theorem kernel_dvd_pellY_double_iff (D : Nat) (hD : PellKernel D) (m : Nat) :
    D ∣ pellY D hD (2*m) ↔ D ∣ pellY D hD m := by
  rw [D_dvd_pellY_iff_rank_dvd_index, D_dvd_pellY_iff_rank_dvd_index]
  exact (Nat.coprime_two_right.mpr (pellRank_odd D hD)).dvd_mul_left

/-- Iterated doubling has the same kernel-saturation condition. -/
theorem kernel_dvd_pellY_two_pow_mul_iff (D : Nat) (hD : PellKernel D)
    (r m : Nat) : D ∣ pellY D hD (2^r*m) ↔ D ∣ pellY D hD m := by
  induction r with
  | zero => simp
  | succ r ih =>
    rw [pow_succ', mul_assoc, kernel_dvd_pellY_double_iff]
    exact ih

/-- The positive quartic source retains its root, ordinate and Cohn branch. -/
theorem positive_quarticPell_coordinates_of_cohn
    (hC : PositiveCohnQuarticPellClassification)
    {D X Y : Nat} (hD : PellKernel D) (hX : 1<X) (hY : 0<Y)
    (heq : X^4=1+D*Y^2) :
    (X^2=fundamentalX D hD ∧ Y=fundamentalY D hD) ∨
    (X^2+1=2*fundamentalX D hD^2 ∧
      Y=2*fundamentalX D hD*fundamentalY D hD) := by
  let A := fundamentalX D hD
  let B := fundamentalY D hD
  have hfund : A^2=1+D*B^2 := by
    have hf := fundamental_pell_equation D hD
    change A^2-D*B^2=1 at hf
    omega
  rcases hC D hD X Y hX hY heq with hfirst | hsecond
  · change X^2=A at hfirst
    refine Or.inl ⟨hfirst, ?_⟩
    have hsq : Y^2=B^2 := by
      apply Nat.eq_of_mul_eq_mul_left (Nat.zero_lt_of_lt hD.1)
      have hx4 : X^4=A^2 := by rw [←hfirst]; ring
      nlinarith
    exact Nat.pow_left_injective (by decide : (2:Nat)≠0) hsq
  · change X^2+1=2*A^2 at hsecond
    refine Or.inr ⟨hsecond, ?_⟩
    have hs := congrArg (fun n : Nat => n^2) hsecond
    have ha := congrArg (fun n : Nat => 4*A^2*n) hfund
    have hsq : Y^2=(2*A*B)^2 := by
      apply Nat.eq_of_mul_eq_mul_left (Nat.zero_lt_of_lt hD.1)
      nlinarith [hs,ha]
    exact Nat.pow_left_injective (by decide : (2:Nat)≠0) hsq

/-- Complete positive saturated quartic classification in a fixed squarefree
field. The reverse direction reconstructs the equation and saturation. -/
theorem positive_saturated_quarticPell_iff
    (hC : PositiveCohnQuarticPellClassification)
    {D X Y : Nat} (hD : PellKernel D) (hX : 1<X) (hY : 0<Y) :
    (X^4=1+D*Y^2 ∧ D ∣ Y) ↔
    D ∣ fundamentalY D hD ∧
      ((X^2=fundamentalX D hD ∧ Y=fundamentalY D hD) ∨
       (X^2+1=2*fundamentalX D hD^2 ∧
        Y=2*fundamentalX D hD*fundamentalY D hD)) := by
  constructor
  · rintro ⟨heq,hdiv⟩
    exact ⟨(kernel_dvd_fundamentalY_iff_pellRank_eq_one D hD).mpr
      (pellRank_eq_one_of_positive_cohn hC hD hX hY heq hdiv),
      positive_quarticPell_coordinates_of_cohn hC hD hX hY heq⟩
  · rintro ⟨hdiv, ⟨hx,hy⟩ | ⟨hx,hy⟩⟩
    · rw [hy]
      refine ⟨?_,hdiv⟩
      have hf := fundamental_pell_equation D hD
      have hx4 : X^4=(fundamentalX D hD)^2 := by rw [←hx]; ring
      omega
    · rw [hy]
      refine ⟨?_,hdiv.trans (dvd_mul_left _ _)⟩
      have hf : (fundamentalX D hD)^2=1+D*(fundamentalY D hD)^2 := by
        have hh := fundamental_pell_equation D hD
        omega
      have hs := congrArg (fun n : Nat => n^2) hx
      have ha := congrArg (fun n : Nat => 4*(fundamentalX D hD)^2*n) hf
      nlinarith [hs,ha]

/-- A certified failure of saturation or of both square-coordinate candidates
rejects every positive saturated quartic source in this field. -/
theorem no_positive_saturated_quarticPell_of_fundamental_filter
    (hC : PositiveCohnQuarticPellClassification) {D X Y : Nat}
    (hD : PellKernel D)
    (hbad : ¬ D ∣ fundamentalY D hD ∨
      ((∀ z : Nat, z^2≠fundamentalX D hD) ∧
       (∀ z : Nat, z^2+1≠2*fundamentalX D hD^2)))
    (hX : 1<X) (hY : 0<Y) (heq : X^4=1+D*Y^2) (hdiv : D ∣ Y) : False := by
  obtain ⟨hf,hfirst | hsecond⟩ :=
    (positive_saturated_quarticPell_iff hC hD hX hY).mp ⟨heq,hdiv⟩
  · rcases hbad with hbad | hbad
    · exact hbad hf
    · exact hbad.1 X hfirst.1
  · rcases hbad with hbad | hbad
    · exact hbad hf
    · exact hbad.2 X hsecond.1

/-- Parity eliminates Cohn's second branch for the even centres in the
square-middle source. -/
theorem even_quarticPell_is_fundamental
    (hCohn : CohnQuarticPellClassification)
    {M X Y : Nat} (h : DivisibleNatQuarticPell M X Y) :
    let hM : PellKernel M := ⟨h.M_one_lt, h.M_squarefree⟩
    X ^ 2 = fundamentalX M hM := by
  dsimp
  rcases hCohn h with hfirst | hsecond
  · exact hfirst
  · have hXSquareEven : Even (X ^ 2) := by
      rw [pow_two]
      exact h.X_even.mul_right X
    have hleftOdd : Odd (X ^ 2 + 1) := hXSquareEven.add_one
    exfalso
    apply hleftOdd.not_two_dvd_nat
    rw [hsecond]
    exact (even_iff_two_dvd.mp (even_two_mul _))

/-- The remaining one-parameter arithmetic obstruction after the Cohn
classification: the fundamental `x` coordinate cannot be an even square at
the same time as the squarefree radicand divides the fundamental `y`
coordinate. -/
def FundamentalUnitSquareDivisibleFree : Prop :=
  ∀ (M : Nat) (hM : PellKernel M),
    M % 8 = 7 →
      ¬ ∃ X : Nat,
        1 < X ∧
          Even X ∧
          fundamentalX M hM = X ^ 2 ∧
          M ∣ fundamentalY M hM

/-- The equivalent combined-rank target for whole square-middle closure.
The square-coordinate hypothesis is essential.  Defining this proposition
does not prove the requested rank inequality. -/
def FundamentalSquareForcesNontrivialRank : Prop :=
  ∀ (M : Nat) (hM : PellKernel M) (X : Nat),
    M % 8 = 7 →
      1 < X → Even X → fundamentalX M hM = X ^ 2 →
        1 < pellRank M hM

/-- The two fundamental-unit targets are unconditionally equivalent;
Cohn is needed only to identify an arbitrary source with a fundamental
solution, not to rewrite this divisibility condition. -/
theorem fundamentalSquareForcesNontrivialRank_iff_fundamentalUnitSquareDivisibleFree :
    FundamentalSquareForcesNontrivialRank ↔
      FundamentalUnitSquareDivisibleFree := by
  constructor
  · intro hRank M hM hmod
    rintro ⟨X, hX, hEven, hfundX, hdiv⟩
    exact (kernel_not_dvd_fundamentalY_iff_one_lt_pellRank M hM).mpr
      (hRank M hM X hmod hX hEven hfundX) hdiv
  · intro hFree M hM X hmod hX hEven hfundX
    apply (kernel_not_dvd_fundamentalY_iff_one_lt_pellRank M hM).mp
    intro hdiv
    exact hFree M hM hmod ⟨X, hX, hEven, hfundX, hdiv⟩

/-- Once the quartic solution is identified with the fundamental Pell
solution in its `x` coordinate, positivity determines its `y` coordinate as
well. -/
private theorem divisibleQuarticPell_y_eq_fundamentalY
    (hCohn : CohnQuarticPellClassification)
    {M X Y : Nat} (h : DivisibleNatQuarticPell M X Y) :
    let hM : PellKernel M := ⟨h.M_one_lt, h.M_squarefree⟩
    Y = fundamentalY M hM := by
  dsimp
  let hM : PellKernel M := ⟨h.M_one_lt, h.M_squarefree⟩
  have hx : X ^ 2 = fundamentalX M hM := by
    simpa [hM] using even_quarticPell_is_fundamental hCohn h
  have hquartic :
      fundamentalX M hM ^ 2 = M * Y ^ 2 + 1 := by
    calc
      fundamentalX M hM ^ 2 = (X ^ 2) ^ 2 := by rw [hx]
      _ = X ^ 4 := by ring
      _ = M * Y ^ 2 + 1 := h.equation
  have hfundSub := fundamental_pell_equation M hM
  have hfund :
      fundamentalX M hM ^ 2 =
        M * fundamentalY M hM ^ 2 + 1 := by
    omega
  have hproducts :
      M * Y ^ 2 = M * fundamentalY M hM ^ 2 := by
    omega
  have hsquares : Y ^ 2 = fundamentalY M hM ^ 2 :=
    Nat.eq_of_mul_eq_mul_left (Nat.zero_lt_of_lt h.M_one_lt) hproducts
  exact Nat.pow_left_injective (by decide : (2 : Nat) ≠ 0) hsquares

/-- Cohn's classification plus the fundamental-unit obstruction excludes all
source-preserving divisible quartic-Pell packages. -/
theorem no_divisibleQuarticPellData_of_cohn
    (hCohn : CohnQuarticPellClassification)
    (hFundamental : FundamentalUnitSquareDivisibleFree) :
    ¬ Nonempty DivisibleQuarticPellData := by
  rintro ⟨data⟩
  let hM : PellKernel data.M :=
    ⟨data.valid.M_one_lt, data.valid.M_squarefree⟩
  have hx : data.X ^ 2 = fundamentalX data.M hM := by
    simpa [hM] using
      even_quarticPell_is_fundamental hCohn data.valid
  have hy : data.Y = fundamentalY data.M hM := by
    simpa [hM] using
      divisibleQuarticPell_y_eq_fundamentalY hCohn data.valid
  have hMdvd : data.M ∣ fundamentalY data.M hM := by
    rw [← hy]
    exact data.valid.M_dvd_Y
  exact
    (hFundamental data.M hM data.valid.kernel_mod_eight)
      ⟨data.X, data.valid.X_one_lt, data.valid.X_even, hx.symm, hMdvd⟩

/-- The conditional fundamental-unit exclusion discharges the existing
right-flank eliminator without changing its source-facing interface. -/
theorem pellShiftClosed_of_cohn_and_fundamentalUnit
    (hCohn : CohnQuarticPellClassification)
    (hFundamental : FundamentalUnitSquareDivisibleFree) :
    PellShiftClosed := by
  rw [pellShiftClosed_iff_no_pairPellCounterexample]
  rintro ⟨data⟩
  apply no_divisibleQuarticPellData_of_cohn hCohn hFundamental
  exact ⟨data.toDivisibleQuarticPellData⟩

/-- Conditional final assembly: the two explicit arithmetic inputs imply the
already-normalized square-middle theorem. -/
theorem squareMiddleClosed_of_cohn_and_fundamentalUnit
    (hCohn : CohnQuarticPellClassification)
    (hFundamental : FundamentalUnitSquareDivisibleFree) :
    ∀ X : Nat, ¬ SquareMiddle X :=
  squareMiddleClosed_of_pellShiftClosed
    (pellShiftClosed_of_cohn_and_fundamentalUnit hCohn hFundamental)

/-- Unconditionally, square-middle closure rules out the fundamental-unit
configuration: such a configuration itself reconstructs divisible
quartic-Pell data and hence a square-middle source. -/
theorem fundamentalUnitSquareDivisibleFree_of_squareMiddleClosed
    (hClosed : ∀ X : Nat, ¬ SquareMiddle X) :
    FundamentalUnitSquareDivisibleFree := by
  intro M hM _hmod
  rintro ⟨X, hX, hEven, hfundX, hMdvd⟩
  apply hClosed X
  apply DivisibleNatQuarticPell.toSquareMiddle (M := M)
      (Y := fundamentalY M hM)
  have hfundSub := fundamental_pell_equation M hM
  have hfundEq :
      fundamentalX M hM ^ 2 =
        M * fundamentalY M hM ^ 2 + 1 := by
    omega
  exact
    { X_one_lt := hX
      X_even := hEven
      Y_pos := fundamentalY_pos M hM
      M_one_lt := hM.1
      M_squarefree := hM.2
      equation := by
        calc
          X ^ 4 = (X ^ 2) ^ 2 := by ring
          _ = fundamentalX M hM ^ 2 := by rw [hfundX]
          _ = M * fundamentalY M hM ^ 2 + 1 := hfundEq
      M_dvd_Y := hMdvd }

/-- Conditional on the source-locked Cohn classification, the one-parameter
fundamental-unit obstruction is exactly square-middle closure, not merely a
sufficient condition for it. -/
theorem fundamentalUnitSquareDivisibleFree_iff_squareMiddleClosed
    (hCohn : CohnQuarticPellClassification) :
    FundamentalUnitSquareDivisibleFree ↔
      ∀ X : Nat, ¬ SquareMiddle X := by
  constructor
  · exact squareMiddleClosed_of_cohn_and_fundamentalUnit hCohn
  · exact fundamentalUnitSquareDivisibleFree_of_squareMiddleClosed

/-- Exact combined-rank reformulation of full source closure under the
explicit Cohn premise.  This is an equivalence, not a proof of either side. -/
theorem fundamentalSquareForcesNontrivialRank_iff_squareMiddleClosed
    (hCohn : CohnQuarticPellClassification) :
    FundamentalSquareForcesNontrivialRank ↔
      ∀ X : Nat, ¬ SquareMiddle X :=
  fundamentalSquareForcesNontrivialRank_iff_fundamentalUnitSquareDivisibleFree.trans
    (fundamentalUnitSquareDivisibleFree_iff_squareMiddleClosed hCohn)

/-- Final assembly with the exact rank target and the source-locked Cohn
classification both retained as explicit hypotheses. -/
theorem squareMiddleClosed_of_cohn_and_fundamentalSquareRank
    (hCohn : CohnQuarticPellClassification)
    (hRank : FundamentalSquareForcesNontrivialRank) :
    ∀ X : Nat, ¬ SquareMiddle X :=
  (fundamentalSquareForcesNontrivialRank_iff_squareMiddleClosed hCohn).mp hRank

end Erdos364
