# Paper I: arXiv source candidate

Title: Shifted-square obstructions at indices divisible by 17 or 41 in a
family of Lucas sequences.

Author: Chey G. A. Loveday (Overdog.ai Ltd, Colchester, England).
Date: 10 September 2026; release 1.0.0 metadata, 11 September 2026.

Licence: the article is released under CC BY 4.0. The ancillary verifier
`anc/verify_fixed_fields.py` is additionally available under Apache-2.0 in
the public release cited as reference [8].

This is the editorially finished source candidate, not the earlier source
archive with SHA-256 a7ca3453663838b61917ac42dec2c53d12418731edf8729d4cc48d67f5599ce1.
That baseline is preserved separately in the repository handoff. Formulae,
numbered results, proof strategy and the verifier remain unchanged.

## Build

```sh
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

The bibliography is contained in main.tex. No BibTeX run, network fetch,
private repository, shell-escape, external graphic or font file is required.
A normal TeX installation supplies the document's standard packages/fonts.
The resulting manuscript is 22 pages in the recorded build environment.
Byte-identical PDFs across different TeX installations are not asserted.

## Finite verification

In a prepared Python environment:

```sh
python -m pip install -r anc/requirements.txt
python anc/verify_fixed_fields.py
```

The requirement versions are pinned, but this is not a hash-locked installer.
Setup may need network access; the verifier itself makes no network requests.
The observed execution and its exact scope are recorded under anc/.

## Integrity

```sh
sha256sum -c SHA256SUMS
```

Reference [8] cites version 1.0.0 of the separate formal development at
<https://github.com/CheyLoveday/erdos-364-shifted-squares/releases/tag/v1.0.0>.
No arXiv upload has been performed by producing this ZIP.
