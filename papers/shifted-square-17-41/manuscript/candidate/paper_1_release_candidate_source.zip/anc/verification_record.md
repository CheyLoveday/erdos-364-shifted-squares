# Paper I exact finite verifier

Editorial candidate: 10 September 2026.

The mathematical content and the Python verifier are unchanged from the
preceding arXiv manuscript bundle. This record describes a new execution;
it does not rewrite the earlier record, preserved in the baseline bundle.

Command:

```sh
python anc/verify_fixed_fields.py
```

Observed environment: Python 3.13.5, SymPy 1.14.0, mpmath 1.3.0.
The available installed environment was used; it was not provisioned afresh.
The supplied requirements file pins the versions, not distribution hashes.

Observed exit status: 0.

```text
SymPy 1.14.0
p=17: polynomial, index and reference checks passed
p=41: polynomial, index and reference checks passed
FIXED_FIELDS_OK
```

Verifier SHA-256:

```text
82e223275f0df061a8a34e6aa8b16be5bbbf8f352245510933d06b01556c80a1
```

The program checks the exact polynomial, index and reference-character data
listed in Appendix C. The manuscript supplies the quantified arguments.
This execution did not rerun Lean, PARI/GP or Magma, and does not compute
individual dyadic Hilbert symbols. No fresh bounded regression campaign is
claimed in this editorial pass.
